# Vulnerable Homework Platform Lab

A deliberately vulnerable student/teacher homework application for local security testing.

## Safety boundary

- Docker network is `internal: true`.
- Web ports bind only to `127.0.0.1`.
- No Docker socket is mounted.
- No host filesystem is mounted.
- The Zabbix "host" is a container named `lab-host`; command execution stays inside that container.
- Do not deploy this stack on a public or shared network.

## Start

```bash
docker compose up --build -d
```

Application: `http://127.0.0.1:8000`

Zabbix: `http://127.0.0.1:8080`

Stop/reset:

```bash
docker compose down -v
```

## Seed users

| Role | Username | Password |
|---|---|---|
| Student | alice | alice123 |
| Student | bob | bob123 |
| Teacher | teacher1 | teach123 |

Zabbix lab intentionally keeps the vendor default frontend login:

- Username: `Admin`
- Password: `zabbix`

## Intended vulnerability chain

1. **IDOR** — authenticate as `alice`, then request submission IDs that do not belong to Alice: `GET /api/submissions/{id}`.
2. **LFI / path traversal** — leaked submission metadata provides a traversal-style clue. Use `GET /api/files?path=...` to read outside `/lab/uploads`.
3. **SQL injection** — the file clue points to `GET /api/lab/user-search?q=...`, which interpolates `q` directly into a PostgreSQL query. The exercise goal is to recover the `cmd_token` value from `lab_secrets`.
4. **Command injection** — send the recovered token as `X-Lab-Token` to `POST /api/lab/ping`; `host` is concatenated into a shell command. Command execution is inside the `app` container.
5. **Zabbix pivot** — the app container has an operations note under `/lab/ops/monitoring.txt`. Zabbix uses the intentionally unchanged `Admin / zabbix` login. The `lab-host` agent has `AllowKey=system.run[*]`, so a Zabbix administrator can execute `system.run[...]` checks inside the `lab-host` container and read `/lab/host-secret.txt`.

The Zabbix bootstrap container tries to create `lab-host` automatically through the Zabbix API. If it runs before the frontend finishes initialization, rerun it:

```bash
docker compose run --rm zabbix-bootstrap
```

## Useful lab checks

Health:

```bash
curl http://127.0.0.1:8000/healthz
```

View logs:

```bash
docker compose logs -f app zabbix-server lab-host
```

Inspect the lab network:

```bash
docker compose ps
```

## Intentional weaknesses

- Plaintext application passwords.
- Weak fixed JWT secret.
- Registration role is client-controlled.
- IDOR on submission lookup.
- LFI/path traversal in file reader.
- SQL injection in user search.
- Command injection in ping utility.
- Zabbix default administrator password.
- Zabbix agent allows unrestricted `system.run[*]`.

These are training defects, not implementation examples for production software.
