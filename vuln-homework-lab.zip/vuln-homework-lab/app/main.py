import os
import time
import subprocess
from datetime import datetime, timedelta, timezone
from pathlib import Path

import jwt
import psycopg2
from psycopg2.extras import RealDictCursor
from fastapi import FastAPI, Request, Form, HTTPException, Depends, Header
from fastapi.responses import HTMLResponse, RedirectResponse, PlainTextResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

DB_URL = os.getenv("DATABASE_URL", "postgresql://homework:homework@db:5432/homework")
JWT_SECRET = os.getenv("JWT_SECRET", "intentionally-weak-jwt-secret")
LAB_CMD_TOKEN = os.getenv("LAB_CMD_TOKEN", "zbx-stage-4-token")
LAB_ROOT = Path("/lab")
UPLOAD_ROOT = LAB_ROOT / "uploads"

app = FastAPI(title="Homework Lab", version="0.1-lab")
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")


def db():
    return psycopg2.connect(DB_URL, cursor_factory=RealDictCursor)


def init_db():
    for _ in range(40):
        try:
            conn = db()
            break
        except Exception:
            time.sleep(1)
    else:
        raise RuntimeError("database unavailable")

    with conn, conn.cursor() as cur:
        cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id SERIAL PRIMARY KEY,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS homeworks (
            id SERIAL PRIMARY KEY,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            teacher_id INTEGER REFERENCES users(id)
        );
        CREATE TABLE IF NOT EXISTS submissions (
            id SERIAL PRIMARY KEY,
            homework_id INTEGER REFERENCES homeworks(id),
            student_id INTEGER REFERENCES users(id),
            content TEXT NOT NULL,
            attachment_path TEXT,
            status TEXT DEFAULT 'submitted',
            grade TEXT,
            teacher_note TEXT
        );
        CREATE TABLE IF NOT EXISTS lab_secrets (
            id SERIAL PRIMARY KEY,
            name TEXT UNIQUE NOT NULL,
            value TEXT NOT NULL
        );
        """)
        cur.execute("SELECT COUNT(*) AS c FROM users")
        if cur.fetchone()["c"] == 0:
            cur.execute("INSERT INTO users(username,password,role) VALUES ('teacher1','teach123','teacher'),('alice','alice123','student'),('bob','bob123','student')")
            cur.execute("SELECT id, username FROM users")
            ids = {r['username']: r['id'] for r in cur.fetchall()}
            cur.execute("INSERT INTO homeworks(title,description,teacher_id) VALUES (%s,%s,%s) RETURNING id", ("Linux homework", "Explain file permissions and submit a text answer.", ids['teacher1']))
            hw = cur.fetchone()['id']
            cur.execute("""INSERT INTO submissions(homework_id,student_id,content,attachment_path,status,grade,teacher_note)
                         VALUES (%s,%s,%s,%s,'graded','A','Good work'),(%s,%s,%s,%s,'submitted',NULL,'private review ref: ../secret/teacher-note.txt')""",
                        (hw, ids['alice'], 'chmod controls mode bits', 'alice.txt', hw, ids['bob'], 'my private answer', 'bob-private.txt'))
            cur.execute("INSERT INTO lab_secrets(name,value) VALUES ('cmd_token',%s),('zabbix_hint','read /lab/ops/monitoring.txt after command execution')", (LAB_CMD_TOKEN,))
    conn.close()


@app.on_event("startup")
def startup():
    init_db()


def make_token(user):
    payload = {
        "sub": str(user["id"]),
        "username": user["username"],
        "role": user["role"],
        "exp": datetime.now(timezone.utc) + timedelta(hours=8),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")


def current_user(request: Request):
    token = request.cookies.get("access_token")
    if not token:
        raise HTTPException(401, "login required")
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
    except jwt.PyJWTError:
        raise HTTPException(401, "invalid token")


@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    token = request.cookies.get("access_token")
    if token:
        return RedirectResponse("/dashboard", status_code=302)
    return templates.TemplateResponse("login.html", {"request": request, "error": None})


@app.get("/register", response_class=HTMLResponse)
def register_form(request: Request):
    return templates.TemplateResponse("register.html", {"request": request, "error": None})


@app.post("/register", response_class=HTMLResponse)
def register(request: Request, username: str = Form(...), password: str = Form(...), role: str = Form("student")):
    # DELIBERATE LAB FLAW: role is trusted from the client.
    try:
        conn = db()
        with conn, conn.cursor() as cur:
            cur.execute("INSERT INTO users(username,password,role) VALUES (%s,%s,%s)", (username, password, role))
        conn.close()
        return RedirectResponse("/", status_code=303)
    except Exception as e:
        return templates.TemplateResponse("register.html", {"request": request, "error": str(e)})


@app.post("/login", response_class=HTMLResponse)
def login(request: Request, username: str = Form(...), password: str = Form(...)):
    conn = db()
    with conn, conn.cursor() as cur:
        cur.execute("SELECT * FROM users WHERE username=%s AND password=%s", (username, password))
        user = cur.fetchone()
    conn.close()
    if not user:
        return templates.TemplateResponse("login.html", {"request": request, "error": "Invalid credentials"}, status_code=401)
    response = RedirectResponse("/dashboard", status_code=303)
    response.set_cookie("access_token", make_token(user), httponly=False, samesite="lax")
    return response


@app.get("/logout")
def logout():
    r = RedirectResponse("/", status_code=302)
    r.delete_cookie("access_token")
    return r


@app.get("/dashboard", response_class=HTMLResponse)
def dashboard(request: Request, user=Depends(current_user)):
    conn = db()
    with conn, conn.cursor() as cur:
        cur.execute("SELECT * FROM homeworks ORDER BY id")
        homeworks = cur.fetchall()
        if user["role"] == "teacher":
            cur.execute("""SELECT s.*, u.username, h.title FROM submissions s JOIN users u ON u.id=s.student_id JOIN homeworks h ON h.id=s.homework_id ORDER BY s.id""")
        else:
            cur.execute("""SELECT s.*, u.username, h.title FROM submissions s JOIN users u ON u.id=s.student_id JOIN homeworks h ON h.id=s.homework_id WHERE s.student_id=%s ORDER BY s.id""", (user["sub"],))
        submissions = cur.fetchall()
    conn.close()
    return templates.TemplateResponse("dashboard.html", {"request": request, "user": user, "homeworks": homeworks, "submissions": submissions})


@app.post("/api/homeworks/create")
def create_homework(title: str = Form(...), description: str = Form(...), user=Depends(current_user)):
    if user["role"] != "teacher":
        raise HTTPException(403, "teachers only")
    conn = db()
    with conn, conn.cursor() as cur:
        cur.execute("INSERT INTO homeworks(title,description,teacher_id) VALUES (%s,%s,%s) RETURNING id",
                    (title, description, user["sub"]))
        hid = cur.fetchone()["id"]
    conn.close()
    return {"ok": True, "homework_id": hid}


@app.post("/api/submissions/{submission_id}/grade")
def grade_submission(submission_id: int, grade: str = Form(...), teacher_note: str = Form(""), user=Depends(current_user)):
    if user["role"] != "teacher":
        raise HTTPException(403, "teachers only")
    conn = db()
    with conn, conn.cursor() as cur:
        cur.execute("UPDATE submissions SET grade=%s, teacher_note=%s, status='graded' WHERE id=%s RETURNING id",
                    (grade, teacher_note, submission_id))
        row = cur.fetchone()
    conn.close()
    if not row:
        raise HTTPException(404, "submission not found")
    return {"ok": True, "submission_id": submission_id, "grade": grade}


@app.post("/api/homeworks/{homework_id}/submit")
def submit_homework(homework_id: int, content: str = Form(...), user=Depends(current_user)):
    if user["role"] != "student":
        raise HTTPException(403, "students only")
    conn = db()
    with conn, conn.cursor() as cur:
        cur.execute("INSERT INTO submissions(homework_id,student_id,content,attachment_path) VALUES (%s,%s,%s,%s) RETURNING id",
                    (homework_id, user["sub"], content, f"submission-{user['sub']}.txt"))
        sid = cur.fetchone()["id"]
    conn.close()
    (UPLOAD_ROOT / f"submission-{user['sub']}.txt").write_text(content)
    return {"ok": True, "submission_id": sid}


@app.get("/api/submissions/{submission_id}")
def get_submission(submission_id: int, user=Depends(current_user)):
    # DELIBERATE VULNERABILITY #1: IDOR. Any authenticated user can read any submission ID.
    conn = db()
    with conn, conn.cursor() as cur:
        cur.execute("""SELECT s.*, u.username, h.title FROM submissions s JOIN users u ON u.id=s.student_id JOIN homeworks h ON h.id=s.homework_id WHERE s.id=%s""", (submission_id,))
        row = cur.fetchone()
    conn.close()
    if not row:
        raise HTTPException(404, "submission not found")
    return row


@app.get("/api/files", response_class=PlainTextResponse)
def read_file(path: str, user=Depends(current_user)):
    # DELIBERATE VULNERABILITY #2: LFI/path traversal.
    # Example chain clue from IDOR can lead outside /lab/uploads.
    target = UPLOAD_ROOT / path
    try:
        return target.read_text(errors="replace")
    except Exception as e:
        raise HTTPException(404, f"cannot read: {e}")


@app.get("/api/lab/user-search")
def vulnerable_user_search(q: str, user=Depends(current_user)):
    # DELIBERATE VULNERABILITY #3: SQL injection.
    # Raw interpolation is intentional for this isolated lab.
    sql = f"SELECT id, username, role FROM users WHERE username ILIKE '%{q}%' ORDER BY id"
    conn = db()
    try:
        with conn, conn.cursor() as cur:
            cur.execute(sql)
            rows = cur.fetchall()
        conn.close()
        return {"query": sql, "rows": rows}
    except Exception as e:
        conn.rollback()
        conn.close()
        return JSONResponse({"query": sql, "db_error": str(e)}, status_code=500)


@app.post("/api/lab/ping")
def vulnerable_ping(host: str = Form(...), x_lab_token: str | None = Header(default=None), user=Depends(current_user)):
    # DELIBERATE VULNERABILITY #4: OS command injection.
    # The token is intentionally stored in the database so SQLi can disclose it.
    if x_lab_token != LAB_CMD_TOKEN:
        raise HTTPException(403, "missing stage token")
    command = f"ping -c 1 {host}"
    try:
        out = subprocess.check_output(command, shell=True, stderr=subprocess.STDOUT, timeout=4, text=True)
    except subprocess.CalledProcessError as e:
        out = e.output
    except Exception as e:
        out = str(e)
    return {"command": command, "output": out}


@app.get("/api/me")
def me(user=Depends(current_user)):
    return user


@app.get("/healthz")
def healthz():
    return {"ok": True, "lab": True}
