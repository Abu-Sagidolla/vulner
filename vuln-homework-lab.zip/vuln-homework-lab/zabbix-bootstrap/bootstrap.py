import json, os, time, urllib.request

URL = os.getenv('ZABBIX_URL', 'http://zabbix-web:8080/api_jsonrpc.php')
USER = os.getenv('ZABBIX_USER', 'Admin')
PASSWORD = os.getenv('ZABBIX_PASSWORD', 'zabbix')
HOST_DNS = os.getenv('LAB_HOST_DNS', 'lab-host')


def call(method, params, auth=None, req_id=1):
    body = {'jsonrpc':'2.0','method':method,'params':params,'id':req_id}
    req = urllib.request.Request(URL, data=json.dumps(body).encode(), headers={'Content-Type':'application/json-rpc', **({'Authorization': f'Bearer {auth}'} if auth else {})})
    with urllib.request.urlopen(req, timeout=5) as r:
        return json.loads(r.read().decode())


def main():
    auth = None
    for _ in range(90):
        try:
            result = call('user.login', {'username':USER,'password':PASSWORD})
            auth = result.get('result')
            if auth:
                break
        except Exception:
            pass
        time.sleep(2)
    if not auth:
        print('Zabbix bootstrap: frontend/API not ready; add host manually.')
        return

    groups = call('hostgroup.get', {'output':['groupid','name']}, auth).get('result', [])
    group_id = next((g['groupid'] for g in groups if g['name']=='Linux servers'), groups[0]['groupid'] if groups else None)
    existing = call('host.get', {'filter':{'host':['lab-host']}, 'output':['hostid']}, auth).get('result', [])
    if existing:
        print('Zabbix bootstrap: lab-host already exists')
        return
    params = {
        'host':'lab-host',
        'name':'lab-host (intentionally vulnerable)',
        'interfaces':[{'type':1,'main':1,'useip':0,'ip':'','dns':HOST_DNS,'port':'10050'}],
        'groups':[{'groupid':group_id}],
        'tags':[{'tag':'lab','value':'vulnerable'}]
    }
    result = call('host.create', params, auth)
    print('Zabbix bootstrap:', result)

if __name__ == '__main__':
    main()
